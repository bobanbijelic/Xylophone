//
//  ViewController.swift
//  Xylophone
//
//  Created by Angela Yu on 27/01/2016.
//  Copyright © 2016 London App Brewery. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate {
    
    var audioPlayer : AVAudioPlayer!
    let soundArray = ["note1", "note2", "note3", "note4", "note5", "note6", "note7"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    @IBAction func notePressed(_ sender: UIButton) {
        //sender.tag se koristi da bi se preko taga odredilo koje dugme na ksilofonu je korisnik pritisnuo
        
        //soundFileName = soundArray[sender.tag - 1]//jer su indeksi u nizu od 0 a tagovi od 1
        
        playSound(soundFileName: soundArray[sender.tag - 1])
    }
    
    func playSound(soundFileName: String) {
        
        let soundURL = Bundle.main.url(forResource: soundFileName, withExtension: "wav") //prvo se pravi put do sound-a
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL!) // onda se audio plejeru kaze da pokusa da pokrene AVAP sa sadrzajem sound-a odozgo
        }                   // AVAP je kao otvaranje i ubacivanje cd-a
        catch {
            print(error)
        }
        
        audioPlayer.play()
        
    }

}









